function loadingStart() { $("#loading-modal").show(); }
function loadingStop()  { $("#loading-modal").hide(); }